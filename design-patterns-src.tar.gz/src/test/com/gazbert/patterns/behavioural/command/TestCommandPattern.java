package com.gazbert.patterns.behavioural.command;

import org.junit.Test;

import com.gazbert.patterns.behavioural.command.commands.DrawCommand;
import com.gazbert.patterns.behavioural.command.commands.ScrollCommand;
import com.gazbert.patterns.behavioural.command.receivers.AnnotationView;
import com.gazbert.patterns.behavioural.command.receivers.MainAppView;

/**
 * Demonstrates use of Command pattern.
 * 
 * @author gazbert
 *
 */
public class TestCommandPattern 
{
    /**
     * This is the Live Assist Interpreter.
     */
    @Test
    public void testCommandPattern() 
    {    
        // in constructor of intepreter, we do this
        
        // Create all the agent commands
        // Not sure how receivers will work in droid... might have to use Application as receiver for all commands?
        final Command drawCommand = new DrawCommand(new AnnotationView());
        final Command scrollCommand = new ScrollCommand(new MainAppView());
        
        // parameterise it
        final CommandInvoker commandInvoker = new CommandInvoker();
        commandInvoker.setCommand("draw", drawCommand);
        commandInvoker.setCommand("scroll", scrollCommand);
        
        // then when message comes in off wire...
        
        //we interpret it - skippin this bit
        
        commandInvoker.onAgentCommand("draw");
        
        // then another one comes in off wire...
        
        commandInvoker.onAgentCommand("draw");
        
        // then a scroll comes in...
        
        commandInvoker.onAgentCommand("scroll");        
    }
}
