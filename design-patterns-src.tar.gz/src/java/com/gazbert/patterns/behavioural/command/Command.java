package com.gazbert.patterns.behavioural.command;

public interface Command
{
    public void execute();
}
