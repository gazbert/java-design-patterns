package com.gazbert.patterns.behavioural.command.receivers;

public class MainAppView
{
    public void scroll()
    {
        System.out.println(MainAppView.class.getSimpleName() + " - scroll()");
    }
}
