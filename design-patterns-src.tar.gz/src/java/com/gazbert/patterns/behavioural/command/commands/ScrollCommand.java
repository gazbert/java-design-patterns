package com.gazbert.patterns.behavioural.command.commands;

import com.gazbert.patterns.behavioural.command.Command;
import com.gazbert.patterns.behavioural.command.receivers.AnnotationView;
import com.gazbert.patterns.behavioural.command.receivers.MainAppView;

/**
 * Concrete command for scrolling consumers current screen up and down.
 * 
 * @author gazbert
 *
 */
public class ScrollCommand implements Command
{
    /** The annotation view receiver */
    private MainAppView mainAppView;
    
    
    /**
     * Constructs the command with recevier.
     * 
     * @param annoationView
     */
    public ScrollCommand(final MainAppView mainAppView)
    {
        this.mainAppView = mainAppView;
    }
    
    @Override
    public void execute()
    {
        mainAppView.scroll();
    }
}
