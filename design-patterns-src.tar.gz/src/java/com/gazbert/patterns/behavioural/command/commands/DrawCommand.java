package com.gazbert.patterns.behavioural.command.commands;

import com.gazbert.patterns.behavioural.command.Command;
import com.gazbert.patterns.behavioural.command.receivers.AnnotationView;

/**
 * Concrete command for drawing agent annotations.
 * 
 * @author gazbert
 *
 */
public class DrawCommand implements Command
{
    /** The annotation view receiver */
    private AnnotationView annoationView;
    
    
    /**
     * Constructs the command with recevier.
     * 
     * @param annoationView
     */
    public DrawCommand(final AnnotationView annoationView)
    {
        this.annoationView = annoationView;
    }
    
    @Override
    public void execute()
    {
        annoationView.draw();
    }
}
