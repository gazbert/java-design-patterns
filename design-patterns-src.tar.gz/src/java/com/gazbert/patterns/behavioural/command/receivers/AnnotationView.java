package com.gazbert.patterns.behavioural.command.receivers;

public class AnnotationView
{
    public void draw()
    {
        System.out.println(AnnotationView.class.getSimpleName() + " - draw()");
    }
}
