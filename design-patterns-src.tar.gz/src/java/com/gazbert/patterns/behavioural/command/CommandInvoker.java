package com.gazbert.patterns.behavioural.command;

import java.util.HashMap;
import java.util.Map;

/**
 * 
 * @author gazbert
 *
 */
public class CommandInvoker
{
    /** Map of all our commands */
    private Map<String, Command> commands = new HashMap<String, Command>();

    /**
     * Sets the commands to invoke, i.e. paramaterise the command invoker.
     * <p>
     * These are all out Live Assist agent commands.
     * 
     * @param id
     * @param command
     */
    public void setCommand(final String id, final Command command)
    {
        commands.put(id, command);
    }
        
    /**
     * The 'business method' - we've receive an agent command from Live Assist server JFDI baby!
     * @param commandId
     */
    public void onAgentCommand(final String commandId)
    {
        // TODO pre-condition check to avoid NPE - is it in map?
        commands.get(commandId).execute();
    }
}
