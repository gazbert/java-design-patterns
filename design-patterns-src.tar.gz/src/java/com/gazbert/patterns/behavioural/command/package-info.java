/**
 * <h2>Command</h2>
 * 

 * 
 * <h2>Actors</h2>
 * <ul>
 * <li>Command interface - </li>
 * <li>Client -  </li>
 * </ul>
 * 
 * <h2>Usages</h2>
 * 
.
 * 
 * <p>
 * @author gazbert
 *
 */
package com.gazbert.patterns.behavioural.command;