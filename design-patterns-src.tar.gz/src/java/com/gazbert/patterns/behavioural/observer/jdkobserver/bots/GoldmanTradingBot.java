package com.gazbert.patterns.behavioural.observer.jdkobserver.bots;


/**
 * Concrete Observer.
 * 
 * @author gazbert
 *
 */
public class GoldmanTradingBot extends AbstractTradingBot
{
}
