package com.gazbert.patterns.behavioural.observer.oldskool.bots;


/**
 * Concrete Observer.
 * 
 * @author gazbert
 *
 */
public class GoldmanTradingBot extends AbstractTradingBot 
{
}
