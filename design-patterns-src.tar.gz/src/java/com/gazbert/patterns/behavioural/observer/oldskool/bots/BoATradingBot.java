package com.gazbert.patterns.behavioural.observer.oldskool.bots;


/**
 * Concrete Observer.
 * 
 * @author gazbert
 *
 */
public class BoATradingBot extends AbstractTradingBot
{
}
