package com.gazbert.patterns.behavioural.observer.jdkobserver.bots;


/**
 * Concrete Observer.
 * <p>
 * 
 * @author gazbert
 *
 */
public class BoATradingBot extends AbstractTradingBot 
{
}
