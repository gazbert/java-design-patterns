package com.gazbert.patterns.behavioural.observer.jdkeventing.bots;


/**
 * Concrete Observer.
 * <p>
 * 
 * @author gazbert
 *
 */
public class BoATradingBot extends AbstractTradingBot 
{
}
