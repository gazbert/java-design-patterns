package com.gazbert.patterns.behavioural.observer;

public class PlaceHolder
{
}
