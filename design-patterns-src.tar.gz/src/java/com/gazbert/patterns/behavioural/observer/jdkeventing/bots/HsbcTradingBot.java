package com.gazbert.patterns.behavioural.observer.jdkeventing.bots;

/**
 * Concrete Observer.
 * 
 * @author gazbert
 *
 */
public class HsbcTradingBot extends AbstractTradingBot
{
}
