package com.gazbert.patterns.creational.builder;

/**
 * Stub for Customer address details.
 * 
 * @author gazbert
 *
 */
public class Address {

}
