package com.gazbert.patterns.structural.decorator;

/**
 * This is a Concrete Component.
 * @author gazbert
 *
 */
public class LoanAccount extends BorrowingAccount {
}
